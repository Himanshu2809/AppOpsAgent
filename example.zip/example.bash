#!/bin/bash
clear
echo "Good morning, world."
